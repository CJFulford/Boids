Boids simulation for assignment 4 in CPSC 597 - Animation W17 University of Calgary.

to compile and run the code on linux, go to the directory with the make file in the terminal and type <make run>

Base code hasbeen used from the standard boiler plate that i have used for this class

to change the parameters of the file. alter the values in the .ini and press R

Controls;
W	raise the camera
S	lower the camera
P	pause simulation
N	recompile shaders
R	reload the .ini file
C 	first person mode

click and drag left mouse button to move the camera
